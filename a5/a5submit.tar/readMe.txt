This folder should have a5.c a5_openCL.cl makefile

Type "make" to compile the program

Type oclgrind ./a5 -i (int) -n(int) -s(int) to run the program

very little error handing for command line input, so be careful.

make sure the the number of kernal is less than 10.

The openCL set up sections in a5.c used lots of source codes from add_numbers created by David Calvert 

Reference: add_numbers from David Calvert

